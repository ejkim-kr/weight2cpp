
import numpy as np

class Predict2Cpp():
    def __init__(self, ):
        self.cpp_array =""

    def getCpp(self, weights: list):

        weights_tmp, maxClm, mdl_shp = [], 0, []
        print(len(weights))

        ## 최대 노드수(배열의 컬럼수)와 모델구조를 생성합니다.(예 1 2 2 1)
        ## dim이 1차원이면 bais임을 이용합니다.
        for cnt, i in enumerate(weights):
            if i.ndim == 1: maxClm = len(i) if maxClm < len(i) else maxClm # 최대 컬럼 수
            if i.ndim == 2: mdl_shp.append(len(i)) #weight 값 row
            if cnt == len(weights)-1: mdl_shp.append(len(i)) # 마지막 출력 수 = 마지막 레이어 clm 수
            print(i, i.shape,"d,l,s=", i.ndim, len(i), i.size)

        Layers = int(len(weights)/2 + 1) #/2는 wegiht, bias로 2개; +1은 입력레이어 추가 분
        Rows = maxClm + 2 # 최대clm수 = 최대row수, 노드구조 상; +2는 bias와 node_output 
        Clms = maxClm
        print("model struct=", mdl_shp);
        print("Layers, Rows, Clms=",Layers, Rows, Clms)
        
        ### zero numpy를 입력레이어 1개, 출력로우 1개를 추가하여 row, clm 최대치로 공간을 확보
        weights_tmp = np.zeros(shape=(Layers, Rows,Clms),dtype=np.float32)

        ### 해당 레이어에 각각의 원소값을 입력, 나머지는 0
        L=0
        for wt in weights:
            if wt.ndim ==2 : 
                L+= 1
                R=0
                for r in range(len(wt)): 
                    for c in range(wt.shape[1]): weights_tmp[L,r,c] = wt[r,c]
            if wt.ndim ==1 : 
                for c in range(wt.shape[0]): weights_tmp[L,r+1,c] = wt[c]

        ## numpy 배열을 CPP에 적합한 배열로 출력
        cpp = ""
        L=0
        print(len(weights_tmp), weights_tmp.shape)
        cpp = "float mdw["+str(Layers)+"]"+"["+str(Rows)+"]"+"["+str(Clms)+"]={" + "\n"
        for wt in weights_tmp:
            L+= 1
            cpp = cpp + "{"
            for r in range(Rows):
                cpp = cpp + "{" 
                for c in range(Clms): cpp = cpp + float(wt[r,c]).hex() + ", " #//= cpp + str(wt[r,c]) + ", "
                cpp = cpp[0:len(cpp)-2]  + "}, \n"
            cpp = cpp[0:len(cpp)-3]  + "}, \n"
        cpp = cpp[0:len(cpp)-3] + "\n}; \n"

        cpp = cpp + "int ln=" + str(Layers) + ";\n"
        cpp = cpp + "int ls[" + str(Layers) + "]=" + str(mdl_shp).replace("[","{").replace("]","}") + ";\n"
        cpp = cpp + "int latf[" + str(Layers) + "]={0,1,0,1,0...}" + "; //Input Activation Function num; latf[0]= input layer \n"

        cpp = cpp + "//int model_struct=" + str(mdl_shp).replace("[","{").replace("]","}") + ";\n"
        cpp = cpp + "//int Layers, Rows, Clms = " + str(Layers) + ", " +str(Rows) + ", " + str(Clms)  + ";\n"

        self.cpp_array = cpp
